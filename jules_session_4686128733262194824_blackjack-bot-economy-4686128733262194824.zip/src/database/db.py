import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore_async
import os

db = None

def init_db(key_path):
    global db
    if not os.path.exists(key_path):
        print(f"ВНИМАНИЕ: Файл ключа Firebase {key_path} не найден!")
        print("Бот будет работать в режиме мок-базы, или упадет при запросах.")
        class MockDB:
            def collection(self, name): return self
            def document(self, name): return self
            async def get(self):
                class MockDoc:
                    exists = False
                    def to_dict(self): return {}
                return MockDoc()
            async def set(self, data, merge=False): pass
            async def update(self, data): pass
            async def stream(self): return []
        db = MockDB()
        return db

    cred = credentials.Certificate(key_path)
    if not firebase_admin._apps:
        firebase_admin.initialize_app(cred)
    db = firestore_async.client()
    return db

def get_db():
    return db
