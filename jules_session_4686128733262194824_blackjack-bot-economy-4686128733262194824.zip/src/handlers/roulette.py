import random
from aiogram import Router, types
from aiogram.filters import Command

from database.user_manager import get_user_data, update_user_balance, check_and_give_bonus
from utils.escape import escape_html

router = Router()

@router.message(Command("roulette"))
async def cmd_roulette(message: types.Message):
    if message.chat.type == "private":
        await message.answer("Играть можно только в группах.")
        return
        
    chat_id = message.chat.id
    user_id = message.from_user.id
    full_name = escape_html(message.from_user.full_name)
    
    data = await get_user_data(chat_id, user_id, full_name)
    if data.get('is_banned', False):
        await message.answer("Вы забанены и не можете играть.")
        return
        
    args = message.text.split()
    if len(args) < 3:
        await message.answer("Использование: <code>/roulette <ставка> <число от 1 до 36></code>\nПример: <code>/roulette 100 15</code>")
        return
        
    try:
        bet = int(args[1])
        guess = int(args[2])
        if bet < 100:
            await message.answer("Минимальная ставка — 100 сыроежек.")
            return
        if not (1 <= guess <= 36):
            await message.answer("Число должно быть от 1 до 36.")
            return
    except ValueError:
        await message.answer("Ставка и число должны быть целыми числами.")
        return

    bonus_given, bonus_amount = await check_and_give_bonus(chat_id, user_id, full_name)
    bonus_text = f"🎁 Вы получили ежедневный бонус: {bonus_amount} сыроежек!\n" if bonus_given else ""
    
    # Re-fetch data after bonus check
    data = await get_user_data(chat_id, user_id, full_name)
    balance = data.get('balance', 0)
    
    if balance - bet < -5000:
        await message.answer(f"{bonus_text}Ваш кредитный лимит (-5000) исчерпан. Пополните баланс.")
        return

    await update_user_balance(chat_id, user_id, -bet)
    
    result_number = random.randint(1, 36)
    diff = abs(result_number - guess)
    
    if diff == 0:
        win_amount = bet * 3
        multiplier_text = "x3 (Точное совпадение!)"
    elif diff <= 2:
        win_amount = int(bet * 1.5)
        multiplier_text = "x1.5 (Разница 1-2 числа)"
    elif diff <= 4:
        win_amount = int(bet * 1.1)
        multiplier_text = "x1.1 (Разница 3-4 числа)"
    else:
        win_amount = 0
        multiplier_text = "Проигрыш (Слишком далеко)"
        
    if win_amount > 0:
        await update_user_balance(chat_id, user_id, win_amount)
        result_text = f"<b>Вы выиграли {win_amount - bet} сыроежек!</b>"
    else:
        result_text = f"<b>Вы проиграли {bet} сыроежек!</b>"
        
    text = (
        f"{bonus_text}"
        f"🎯 Рулетка крутится...\n"
        f"Выпало число: <b>{result_number}</b> (Ваш выбор: {guess})\n\n"
        f"{result_text}\n"
        f"Множитель: {multiplier_text}"
    )
    
    await message.answer(text)
